// // lib/services/translation_engine.dart
// // Full translation pipeline — exact port of the Android pipeline:
// //
// //   Step 0: FuzzyMatcher      — fix STT spelling errors (Roman Urdu)
// //   Step 1: UrduSlangNormalizer — slang/Urdish → standard Urdu
// //   Step 2: WordDictionary    — substitute known words (production mode)
// //   Step 3: TranslationCache  — return cached result if available
// //   Step 4: MarianTranslator  — on-device Urdu→English ONNX
// //   Step 5: If target ≠ English, chain second Marian pass
// //           (future: multilingual Marian models)
// //   Step 6: Store result in cache + word dictionary
// //
// // No Google services. No network calls during translation.

// import 'package:flutter/foundation.dart';
// import 'marian_translator.dart';
// import '../utils/fuzzy_matcher.dart';
// import '../utils/urdu_slang_normalizer.dart';
// import '../utils/word_dictionary.dart';
// import '../utils/translation_cache.dart';
// import '../utils/translation_context.dart';

// // ── Result type ───────────────────────────────────────────────────────────────

// class TranslationResult {
//   final String original;
//   final String translated;
//   final String normNote;        // e.g. "Normalised slang"
//   final String correctionNote;  // e.g. "Fuzzy fixed: meetng → meeting"
//   final bool   fromCache;
//   final double confidence;      // 0..1
//   final String sourceLang;
//   final String targetLang;

//   const TranslationResult({
//     required this.original,
//     required this.translated,
//     this.normNote       = '',
//     this.correctionNote = '',
//     this.fromCache      = false,
//     this.confidence     = 1.0,
//     required this.sourceLang,
//     required this.targetLang,
//   });

//   bool get hasTranslation => translated.isNotEmpty && translated != original;
// }

// // ── Engine singleton ──────────────────────────────────────────────────────────

// class TranslationEngine {
//   static final TranslationEngine _instance = TranslationEngine._();
//   factory TranslationEngine() => _instance;
//   TranslationEngine._();

//   bool _isInitialized = false;
//   bool get isInitialized => _isInitialized;

//   final MarianTranslator   _marian  = MarianTranslator();
//   final WordDictionary     _dict    = WordDictionary();
//   final TranslationCache   _cache   = TranslationCache();
//   final TranslationContext _context = TranslationContext();

//   bool _marianLoaded = false;
//   bool _initializing = false;

//   bool get isMarianLoaded => _marianLoaded;

//   // ── Init ──────────────────────────────────────────────────────────────────

//   Future<void> init() async {
//     if (_initializing) return;
//     _initializing = true;

//     await _cache.init();
//     await _dict.init();

//     try {
//       await _marian.load();
//       _marianLoaded = true;
//       debugPrint('[TranslationEngine] Marian READY');
//     } catch (e) {
//       _marianLoaded = false;
//       debugPrint('[TranslationEngine] Marian load failed: $e — pipeline will use cache only');
//     }

//     _initializing = false;
//     _isInitialized = true;
//   }

//   // ── Main translate ─────────────────────────────────────────────────────────

//   Future<TranslationResult> translate({
//     required String text,
//     required String sourceLang,
//     required String targetLang,
//   }) async {
//     if (text.trim().isEmpty) {
//       return TranslationResult(original: text, translated: text, sourceLang: sourceLang, targetLang: targetLang);
//     }

//     String working = text.trim();
//     String correctionNote = '';
//     String normNote       = '';

//     // ── Step 0: Fuzzy spelling correction (Roman Urdu only) ──────────────────
//     if (sourceLang == 'ur') {
//       final fuzzy = FuzzyMatcher.correct(working);
//       if (fuzzy.wasModified) {
//         working       = fuzzy.corrected;
//         correctionNote = '🔤 ${fuzzy.changesApplied.take(2).join(', ')}';
//       }
//     }

//     // ── Step 1: Slang / Urdish normalisation ─────────────────────────────────
//     if (sourceLang == 'ur') {
//       final normalized = UrduSlangNormalizer.normalize(working, sourceLang);
//       if (normalized.wasModified) {
//         normNote = UrduSlangNormalizer.describeChanges(working, normalized);
//         working  = normalized.text;
//       }
//     }

//     // ── Step 2: Word dictionary substitution (production mode) ───────────────
//     final dictResult = _dict.substituteKnownWords(working, sourceLang, targetLang);
//     if (dictResult.wasModified) working = dictResult.text;

//     // ── Step 3: Cache lookup ──────────────────────────────────────────────────
//     final cached = _cache.lookup(working, sourceLang, targetLang);
//     if (cached != null) {
//       _context.recordTranslation(
//         source: text, target: cached, sourceLang: sourceLang, targetLang: targetLang,
//       );
//       return TranslationResult(
//         original: text, translated: cached,
//         normNote: normNote, correctionNote: correctionNote,
//         fromCache: true, sourceLang: sourceLang, targetLang: targetLang,
//       );
//     }

//     // ── Step 4: Marian on-device inference ───────────────────────────────────
//     String? translated;

//     if (_marianLoaded && sourceLang == 'ur') {
//       // Marian handles ur → en
//       translated = await _marian.translateToEnglish(working);
//     }

//     // ── Step 5: Fallback chain ────────────────────────────────────────────────
//     // If Marian didn't produce a result, or source is not Urdu,
//     // we return the input as-is with a note.
//     // In a full deployment, you'd add more Marian models or
//     // a secondary offline engine here (e.g., CTranslate2).
//     translated ??= _noTranslationFallback(working, sourceLang, targetLang);

//     final finalTranslation = translated;

//     // ── Step 6: Cache the result ──────────────────────────────────────────────
//     await _cache.store(
//       source: working, target: finalTranslation,
//       sourceLang: sourceLang, targetLang: targetLang,
//       type: CacheEntryType.modelBasic,
//     );

//     // ── Step 7: Record in context ─────────────────────────────────────────────
//     _context.recordTranslation(
//       source: text, target: finalTranslation,
//       sourceLang: sourceLang, targetLang: targetLang,
//     );

//     // ── Step 8: Learn word pairs ──────────────────────────────────────────────
//     await _dict.learnFromTranslation(
//       sourceText: working, targetText: finalTranslation,
//       sourceLang: sourceLang, targetLang: targetLang,
//       verified: false,
//     );

//     return TranslationResult(
//       original: text, translated: finalTranslation,
//       normNote: normNote, correctionNote: correctionNote,
//       fromCache: false,
//       confidence: _marianLoaded ? 0.85 : 0.5,
//       sourceLang: sourceLang, targetLang: targetLang,
//     );
//   }

//   // ── User corrects a translation ───────────────────────────────────────────

//   Future<void> userCorrect({
//     required String source,
//     required String corrected,
//     required String sourceLang,
//     required String targetLang,
//   }) async {
//     await _cache.userCorrect(
//       source: source, corrected: corrected,
//       sourceLang: sourceLang, targetLang: targetLang,
//     );
//     await _dict.learnFromTranslation(
//       sourceText: source, targetText: corrected,
//       sourceLang: sourceLang, targetLang: targetLang,
//       verified: true,
//     );
//   }

//   // ── Clear session context ─────────────────────────────────────────────────

//   void clearSession() => _context.clearSession();

//   // ── Stats ─────────────────────────────────────────────────────────────────

//   CacheStats get cacheStats => _cache.getStats();
//   int get dictionarySize    => _dict.size;

//   Future<String> exportTrainingData() async {
//     final file = await _cache.exportTrainingData();
//     return file.path;
//   }

//   // ── Cleanup ───────────────────────────────────────────────────────────────

//   void close() {
//     _marian.close();
//     _marianLoaded = false;
//     _isInitialized = false;
//   }

//   // ── Fallback when no model is available ───────────────────────────────────

//   String _noTranslationFallback(String text, String src, String tgt) {
//     // For non-Urdu languages without a Marian model loaded,
//     // return the original text so the UI can show it honestly.
//     // A real deployment would add more language-pair ONNX models here.
//     if (src == tgt) return text;
//     return text; // caller shows "Model not loaded" status badge
//   }
// }

// lib/services/translation_engine.dart

import 'dart:convert';
import 'dart:io';
import 'package:onnxruntime/onnxruntime.dart';
import 'model_manager.dart';

class TranslationEngine {
  final ModelManager _modelManager = ModelManager();

  OrtSession? _encoderSession;
  OrtSession? _decoderSession;
  Map<String, int>? _tokenizer;
  List<String>? _idToToken;

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  CacheStats get cacheStats => CacheStats(); // Implement as needed
  int get dictionarySize => _tokenizer?.length ?? 0;

  Future<void> init() async {
    if (_isInitialized) return;

    try {
      if (!_modelManager.isMarianReady) {
        print('Marian models not ready yet');
        return;
      }

      // Load tokenizer
      final tokenizerFile = File(_modelManager.marianTokenizerPath);
      if (await tokenizerFile.exists()) {
        final content = await tokenizerFile.readAsString();
        final jsonData = jsonDecode(content);

        // Handle the direct mapping format
        if (jsonData is Map<String, dynamic>) {
          _tokenizer = {};
          _idToToken = List.filled(65000, '');

          jsonData.forEach((token, id) {
            final int tokenId = id as int;
            _tokenizer![token] = tokenId;
            if (tokenId < _idToToken!.length) {
              _idToToken![tokenId] = token;
            }
          });

          print('Loaded tokenizer with ${_tokenizer!.length} entries');
        }
      }

      // Load encoder and decoder models
      final opts = OrtSessionOptions()
        ..setIntraOpNumThreads(4)
        ..setInterOpNumThreads(4);

      final encoderFile = File(_modelManager.marianEncoderPath);
      final decoderFile = File(_modelManager.marianDecoderPath);

      if (await encoderFile.exists() && await decoderFile.exists()) {
        _encoderSession = await OrtSession.fromFile(encoderFile, opts);
        _decoderSession = await OrtSession.fromFile(decoderFile, opts);
        _isInitialized = true;
        print('Translation engine initialized successfully');
      } else {
        print('Model files not found: ${_modelManager.marianEncoderPath}');
      }
    } catch (e) {
      print('Error initializing translation engine: $e');
      _isInitialized = false;
    }
  }

  Future<TranslationResult> translate({
    required String text,
    required String sourceLang,
    required String targetLang,
  }) async {
    if (!_isInitialized) {
      print('Translation engine not initialized');
      return TranslationResult(
        original: text,
        translated: text,
        confidence: 0.0,
        fromCache: false,
      );
    }

    try {
      // Simple tokenization (split by spaces)
      final words = text.split(' ');
      final inputIds = <int>[];

      for (final word in words) {
        final token = _tokenizer![word];
        if (token != null) {
          inputIds.add(token);
        } else {
          // Use unknown token
          inputIds.add(_tokenizer!['<unk>'] ?? 1);
        }
      }

      if (inputIds.isEmpty) {
        return TranslationResult(
          original: text,
          translated: text,
          confidence: 0.0,
          fromCache: false,
        );
      }

      // Add start and end tokens
      final startToken = _tokenizer!['<s>'] ?? 1;
      final endToken = _tokenizer!['</s>'] ?? 0;
      final tokensWithMarkers = [startToken, ...inputIds, endToken];

      // Run encoder
      final inputTensor =
          OrtTensor.int64(tokensWithMarkers, [1, tokensWithMarkers.length]);

      final encoderOutputs = await _encoderSession!.run(
        OrtRunOptions(),
        {'input_ids': inputTensor},
        ['last_hidden_state'],
      );
      inputTensor.release();

      final encoderHidden = encoderOutputs.first as OrtValueTensor;

      // Simple decoder (greedy)
      final decodedTokens = <int>[];
      int currentToken = startToken;

      for (int i = 0; i < 100; i++) {
        // Max 100 tokens
        final decoderInput = OrtTensor.int64([currentToken], [1, 1]);

        final decoderOutputs = await _decoderSession!.run(
          OrtRunOptions(),
          {
            'input_ids': decoderInput,
            'encoder_hidden_states': encoderHidden,
          },
          ['logits'],
        );
        decoderInput.release();

        final logitsTensor = decoderOutputs.first as OrtValueTensor;
        final logits = logitsTensor.value as List<dynamic>;
        final lastLogits = (logits[0] as List<dynamic>)[0] as List<dynamic>;

        // Get token with highest probability
        int nextToken = 0;
        double maxVal = double.negativeInfinity;
        for (int j = 0; j < lastLogits.length; j++) {
          final val = (lastLogits[j] as num).toDouble();
          if (val > maxVal) {
            maxVal = val;
            nextToken = j;
          }
        }
        logitsTensor.release();

        if (nextToken == endToken) break;
        if (nextToken < _idToToken!.length) {
          decodedTokens.add(nextToken);
        }
        currentToken = nextToken;
      }

      encoderHidden.release();

      // Decode tokens back to text
      final translatedWords = decodedTokens.map((id) {
        if (id < _idToToken!.length && _idToToken![id] != null) {
          String token = _idToToken![id]!;
          // Remove special prefix (▁) and join
          token = token.replaceAll('▁', ' ');
          return token.trim();
        }
        return '?';
      }).toList();

      final translatedText = translatedWords.join(' ').trim();

      return TranslationResult(
        original: text,
        translated: translatedText.isNotEmpty ? translatedText : text,
        confidence: 0.8,
        fromCache: false,
      );
    } catch (e) {
      print('Translation error: $e');
      return TranslationResult(
        original: text,
        translated: text,
        confidence: 0.0,
        fromCache: false,
      );
    }
  }

  Future<void> userCorrect(String source, String corrected, String sourceLang,
      String targetLang) async {
    // Implement user correction logic
    print('User correction: $source -> $corrected');
  }

  Future<String> exportTrainingData() async {
    return ''; // Implement if needed
  }

  void clearSession() {
    // Clear any session data
  }

  void close() {
    _encoderSession?.release();
    _decoderSession?.release();
  }
}

class TranslationResult {
  final String original;
  final String translated;
  final double confidence;
  final bool fromCache;
  final String normNote;
  final String correctionNote;

  TranslationResult({
    required this.original,
    required this.translated,
    required this.confidence,
    required this.fromCache,
    this.normNote = '',
    this.correctionNote = '',
  });
}

class CacheStats {
  // Implement as needed
}
